# dio-curso-etl
Curso oferecido para a DIO sobre ETL utilizando a linguagem Python e as bibliotecas pandas e pandera.
